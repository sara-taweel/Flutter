package com.example.tickapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
